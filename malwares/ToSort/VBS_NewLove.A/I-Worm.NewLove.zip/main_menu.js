img1 = new Image ()
img1.src = "/images/products_over.gif"

img2 = new Image ()
img2.src = "/images/company_info_over.gif"

img3 = new Image ()
img3.src = "/images/news_over.gif"

img4 = new Image ()
img4.src = "/images/support_over.gif"

img5 = new Image ()
img5.src = "/images/investor_relations_over.gif"

img6 = new Image ()
img6.src = "/images/employment_over.gif"

img7 = new Image ()
img7.src = "/images/estore_over.gif"

img8 = new Image ()
img8.src = "/images/nav_sitemap_over.gif"

img9 = new Image ()
img9.src = "/images/nav_privacy_over.gif"

img10 = new Image ()
img10.src = "/images/nav_legal_over.gif"

img11 = new Image ()
img11.src = "/images/nav_contact_over.gif"

img12 = new Image ()
img12.src = "/images/downloads_over.gif"

img13 = new Image ()
img13.src = "/images/virusnh_over.gif"


if (document.images) {
  image1on = new Image();
  image1on.src = "/images/products_over.gif";

  image2on = new Image();
  image2on.src = "/images/company_info_over.gif";

  image3on = new Image();
  image3on.src = "/images/news_over.gif";

  image4on = new Image();
  image4on.src = "/images/support_over.gif";

  image5on = new Image();
  image5on.src = "/images/investor_relations_over.gif";

  image6on = new Image();
  image6on.src = "/images/employment_over.gif";

  image7on = new Image();
  image7on.src = "/images/estore_over.gif";

  image8on = new Image();
  image8on.src = "/images/nav_sitemap_over.gif";

  image9on = new Image();
  image9on.src = "/images/nav_privacy_over.gif";

  image10on = new Image();
  image10on.src = "/images/nav_legal_over.gif";
  
  image11on = new Image();
  image11on.src = "/images/nav_contact_over.gif";
  
  image12on = new Image();
  image12on.src = "/images/downloads_over.gif";

  image13on = new Image();
  image13on.src = "/images/virusnh_over.gif";

  image1off = new Image();
  image1off.src = "/images/products.gif";

  image2off = new Image();
  image2off.src = "/images/company_info.gif";

  image3off = new Image();
  image3off.src = "/images/news.gif";

  image4off = new Image();
  image4off.src = "/images/support.gif";

  image5off = new Image();
  image5off.src = "/images/investor_relations.gif";

  image6off = new Image();
  image6off.src = "/images/employment.gif";

  image7off = new Image();
  image7off.src = "/images/estore.gif";

  image8off = new Image();
  image8off.src = "/images/nav_sitemap.gif";

  image9off = new Image();
  image9off.src = "/images/nav_privacy.gif";

  image10off = new Image();
  image10off.src = "/images/nav_legal.gif";
  
  image11off = new Image();
  image11off.src = "/images/nav_contact.gif";
  
  image12off = new Image();
  image12off.src = "/images/downloads.gif";

  image13off = new Image();
  image13off.src = "/images/virusnh.gif";
 
}

function changeImages() {
  if (document.images) {
    for (var i=0; i<changeImages.arguments.length; i+=2) {
      document[changeImages.arguments[i]].src = eval(changeImages.arguments[i+1] + ".src");
    }
  }
}
